export default defineComponent({
  setup() {
    return () => (
      <div class="home-page">
        <h1>Home</h1>
      </div>
    );
  },
});
