export default defineComponent({
  /* eslint-disable-next-line max-lines-per-function */
  setup() {
    return () => (
      <guest-layout>
        <div class="sign-in">
          <h1>Sign In</h1>
        </div>
      </guest-layout>
    );
  },
});
