import favicon from 'assets/images/favicon.png';
import avatarDefault from 'assets/images/avatar-default.svg';

export default {
  FAVICON: favicon,
  AVATAR_DEFAULT: avatarDefault,
};
