export default defineComponent({
  setup() {
    return () => <router-view />;
  },
});
