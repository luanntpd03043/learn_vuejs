export { default } from './FontIcon';
