import type { State } from './types';

export default (): State => ({
  //
});
