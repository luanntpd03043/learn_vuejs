import type { StoreOptions } from './types';

const getters: StoreOptions['getters'] = {
  //
};

export default getters;
