declare const APP_URL: string;
declare const API_URL: string;
declare const NODE_ENV: string;
