export default defineComponent({
  setup() {
    return (): JSX.Element => <div>Page Not Found</div>;
  },
});
